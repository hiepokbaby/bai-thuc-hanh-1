
    
 
import java.util.Scanner;

public class Slide40 {
 

 {
 
    public static void main(String[] arStrings) {
        int ngay=scan.nextInt();
    
        Scanner scanner = new Scanner(System.in);
         
       
         
        switch (HienThiNgayCuaTuan) {
            case 0:system.out.println("Chu nhat");
            break;
            case 1:system.out.println("Thu hai");
            break;
            case 2:system.out.println("Thu ba");
            break;
             case 3:system.out.println("Thu tu");
            break;
             case 4:system.out.println("Thu nam");
            break;
             case 5:system.out.println("Thu sau");
            break;
             case 6:system.out.println("Thu bay");
            break;
            


         
            default:system.out.println("so ngay trong tuan sai ");
            }
    }
 
}